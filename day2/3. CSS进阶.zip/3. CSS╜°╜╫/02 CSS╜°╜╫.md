# CSS进阶

### <font><strong>本章概述</strong></font>

​        本章节主要讲解CSS高级选择器、CSS元素显示类型及可见性、CSS定位、CSS浮动、CSS对齐式、CSS图像拼合技术等CSS进阶知识。

##### 知识目标

- 了解CSS有哪几类高级选择器
- 了解CSS高级选择器的使用方法
- 理解什么是浮动
- 理解CSS定位类型
- 了解css sprites的优劣及使用方法

##### 技能目标

- 能够使用高级选择器对元素样式进行配置
- 能够配置元素的显示样式
- 能够配置鼠标的样式
- 能够使用CSS定位属性对元素进行定位
- 能够使用浮动设计特殊效果
- 能够使用CSS设置各类居中
- 能够使用CSS精灵拼合图标

### 教学内容

## 第一节、CSS高级选择器(重点)

## 1.1、CSS 链接选择器 (UI伪类选择器)

### 1.1.1、链接样式

不同的链接可以有不同的样式。

链接的样式，可以用任何CSS属性（如颜色，字体，背景等）。

特别的链接，可以有不同的样式，这取决于他们是什么状态。

这四个链接状态是：

> a:link - 正常，未访问过的链接
>
> a:visited - 用户已访问过的链接
>
> a:hover - 当用户鼠标放在链接上时
>
> a:active - 链接被点击的那一刻

```css
a:link {color:#000000;} /* 未访问链接*/
a:visited {color:#00FF00;} /* 已访问链接 */
a:hover {color:#FF00FF;} /* 鼠标移动到链接上 */
a:active {color:#0000FF;} /* 鼠标点击时 */
```

当设置为若干链路状态的样式，也有一些顺序规则：

a:hover 必须跟在 a:link 和 a:visited后面

a:active 必须跟在 a:hover后面

L  V  H  A

### 1.1.2、常见的链接样式

根据上述链接的颜色变化的例子，看它是在什么状态。

让我们通过一些其他常见的方式转到链接样式：

```css
a:link {text-decoration:none;}
a:visited {text-decoration:none;}
a:hover {text-decoration:underline;}
a:active {text-decoration:underline;}
```

背景颜色属性指定链接背景色：

```css
a:link {background-color:#B2FF99;}
a:visited {background-color:#FFFF85;}
a:hover {background-color:#FF704D;}
a:active {background-color:#FF704D;}
```

### 1.2.1、分组选择器

在样式表中有很多具有相同样式的元素。

```css
h1
{
    color:green;
}
h2
{
    color:green;
}
p
{
    color:green;
}
```

为了尽量减少代码，你可以使用分组选择器。

每个选择器用逗号分隔。

```css
h1,h2,p { color:green; }
```

### 1.2.2、交集选择器

选择既是某种类型又是某种类型的元素

p.marked{ }: 为所有 class="marked" 的 p 元素指定一个样式。

```css
p.marked{
    text-decoration:underline;
}
```

## 1.3、CSS 组合选择符(CSS关系选择器)

组合选择符说明了两个选择器直接的关系。

CSS组合选择符包括各种简单选择符的组合方式。

在 CSS 中包含了四种组合方式:

> 后代选择器(以空格分隔)
>
> 子元素选择器(以大于号分隔）
>
> 相邻兄弟选择器（以加号分隔）
>
> 普通兄弟选择器（以破折号分隔）
>

### 1.3.1、后代选择器

后代选择器用于选取某元素的后代元素。

```css
div p {
    background-color:yellow; /*选择div的所有后代p元素*/
}  
```

### 1.3.2、子元素选择器

与后代选择器相比，子元素选择器（Child selectors）只能选择作为某元素子元素的元素。

```css
div>p {
    background-color:yellow; /*选择div的所有子元素p元素*/
}
```

### 1.3.3、相邻兄弟选择器

相邻兄弟选择器（Adjacent sibling selector）可选择紧接在另一元素后的元素，且二者有相同父元素。

如果需要选择紧接在另一个元素后的元素，而且二者有相同的父元素，可以使用相邻兄弟选择器（Adjacent sibling selector）。

```css
div+p {
    background-color:yellow; /*选择div之后紧邻的兄弟p元素*/
}
```

**案例**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    div+p{
      color: red;
    }
  </style>
</head>
<body>
  <div>d1</div>
  <p>2</p>
  <p>3</p>
</body>
</html>
```

### 1.3.4、后续兄弟选择器

后续兄弟选择器选取所有指定元素之后的所有兄弟元素。

```css
div~p {
    background-color:yellow;
}
```

**案例**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    div~p{
      color: red;
    }
  </style>
</head>
<body>
  <div>d1</div>
  <p>2</p>
  <p>3</p>
</body>
</html>
```

## 1.4、CSS属性选择器

| 选择器       | 示例        | 示例说明                               |
| ---------------- | --------------- | ------------------------------------------ |
| attribute        | [target]        | 选择所有带有target属性元素                 |
| attribute=value  | [target=_blank] | 选择所有使用target="-blank"的元素          |
| attribute~=value | [title~=flower] | 选择标题属性**包含单词**"flower"的所有元素 |

**属性选择器**

```html
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    /* 所有带target的元素 */
    [target] {
      color: red;
    }

    /* 选择具有特定target属性值的元素 */
    [target="_blank"] {
      font-weight: bold;
    }

    /* 选择标题属性中包含特定单词的元素 */
    [title~=flower] {
      background-color: yellow;
    }
  </style>
</head>

<body>
  <a href="https://www.example.com" target="_blank">Example 1</a>
  <a href="https://www.example2.com">Example 2</a>
  <a href="https://www.example3.com" target="_self">Example 3</a>

  <p title="flower garden">This is a flower garden.</p>
  <p title="flower pot">This is a flower pot.</p>
  <p title="garden">This is a garden.</p>
</body>

</html>
```

## 1.5、CSS伪元素选择器(和元素内容有关)

| 选择器    | 示例       | 示例说明                                                 |
| ------------- | -------------- | ------------------------------------------------------------ |
| :first-letter | p:first-letter | 选择每一个```<P>```元素的第一个字母                          |
| :first-line   | p:first-line   | 选择每一个```<P>```元素的第一行                              |
| :after        | p:after        | 在每个```<p>```元素之后插入内容使用content 属性来指定要插入的内容。 |
| :before       | p:before       | 在每个```<p>```元素之前插入内容使用content 属性来指定要插入的内容。 |

**案例1：**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>示例 1</title>
    <style>
        p:after {
            content: " 这是段落结束啦！";
        }

        p:before {
            content: "开始啦！ ";
        }
    </style>
</head>

<body>
    <p>这是一段普通的文本。</p>
    <p>这是另一段普通的文本。</p>
</body>

</html>
```

**案例2：**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>示例 2</title>
    <style>
      li:after {
          content: " ✔";
      }

      li:before {
          content: "👉 ";
      }
  </style>
</head>

<body>
    <ul>
        <li>苹果</li>
        <li>香蕉</li>
        <li>橙子</li>
    </ul>
</body>

</html>
```

**案例3：**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        a:after {
            content: " 🔗";
        }

        a:before {
            content: "🌐 ";
        }
    </style>
    <title>示例 3</title>
</head>

<body>
    <a href="https://www.example.com">示例网站</a>
    <a href="https://www.google.com">谷歌</a>
</body>

</html>
```

更多案例：https://juejin.cn/post/6854573204011221000?searchId=20250304161555AB9052027619DCBA5761

## 1.6、CSS结构伪类选择器

| 选择器             | 示例              | 示例说明                                                                 |
|--------------------|-------------------|--------------------------------------------------------------------------|
| `:first-child`     | `p:first-child`   | 指定只有当 `<p>` 元素是其父级的第一个子级的样式。                        |
| `:last-child`      | `div:last-child`  | 选择父元素的最后一个子元素（例如，如果 `div` 是最后一个子元素则应用样式）。|
| `:nth-child(n)`    | `ul li:nth-child(2)` | 选择父元素的第 `n` 个子元素（例如，选择 `ul` 中的第二个 `li` 元素）。     |
| `:nth-last-child(n)` | `div:nth-last-child(1)` | 从父元素的最后一个子元素开始计数，选择第 `n` 个子元素。                |
| `:only-child`      | `p:only-child`    | 选择父元素中唯一的子元素（例如，如果 `p` 是唯一的子元素则应用样式）。     |
| `:empty`           | `div:empty`       | 选择没有子元素的元素（包括没有文本内容的元素）。                         |
| `:not`             | `:not(p)`         | 选择所有不是 `p` 元素的元素。                                            |
| `:root`            | `:root`           | 选择文档的根元素（通常是 `html` 元素）。                                 |
| `:target`          | `#example:target` | 选择当前活动的片段标识符（即 URL 中 `#` 后面的部分）。                   |
| `::before`         | `p::before`       | 在元素的内容之前插入内容（通常与 `content` 属性一起使用）。               |
| `::after`          | `p::after`        | 在元素的内容之后插入内容（通常与 `content` 属性一起使用）。  

**案例**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>综合伪类选择器示例</title>
    <style>
        /* 使用 :root 定义全局变量 */
        :root {
            --main-color: #007BFF;
            --highlight-color: #FFC107;
            --text-color: #333;
        }

        body {
            font-family: Arial, sans-serif;
            color: var(--text-color);
        }

        /* 选择 ul 下的第一个 li 元素 */
        ul li:first-child {
            color: var(--main-color);
            font-weight: bold;
        }

        /* 选择 ul 下的最后一个 li 元素 */
        ul li:last-child {
            color: var(--highlight-color);
            font-style: italic;
        }

        /* 选择 ul 下的偶数位置的 li 元素 */
        ul li:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* 选择 ul 下除了第一个和最后一个之外的 li 元素 */
        ul li:not(:first-child):not(:last-child) {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <h1>综合伪类选择器效果展示</h1>
    <ul>
        <li>列表项 1</li>
        <li>列表项 2</li>
        <li>列表项 3</li>
        <li>列表项 4</li>
        <li>列表项 5</li>
    </ul>
</body>

</html>
```

## 1.7、CSS焦点选择器

| 选择器 | 示例    | 示例说明           |
| ---------- | ----------- | ---------------------- |
| :focus     | input:focus | 选择具有焦点的输入元素 |

# 第二节、CSS元素显示类型及可见性

## 2.1、CSS Display

display属性设置一个元素应如何显示。

| 值       | 描述                                             |
| ------------ | ---------------------------------------------------- |
| none         | 此元素不会被显示。                                   |
| block        | 此元素将显示为块级元素，此元素前后会带有换行符。     |
| inline       | 默认。此元素会被显示为内联元素，元素前后没有换行符。 |
| inline-block | 行内块元素。（CSS2.1 新增的值）                      |

其他：list-item/table/inline-table/table-cell/table-caption......，不过由于缺乏广泛支持或者支持程度不好，有的已经被删除或者很少使用；

## 2.2、CSS Visibility

visibility属性指定一个元素应可见还是隐藏。

| 值  | 描述               |
| ------- | ---------------------- |
| visible | 默认值。元素是可见的。 |
| hidden  | 元素是不可见的。       |

**display和visibility案例：**

```html
<!DOCTYPE html>
<html>
<head>
  <style>
    .box {
      width: 200px;
      height: 100px;
      margin: 10px;
      background: lightblue;
      border: 2px solid blue;
    }

    .display-none {
      display: none; /* 完全隐藏且不占空间 */
    }

    .visibility-hidden {
      visibility: hidden; /* 隐藏但保留空间 */
    }

    /* 子元素可见性控制示例 */
    .parent {
      visibility: hidden;
      background: pink;
      padding: 20px;
    }
    .child {
      visibility: visible; /* 强制子元素可见 */
    }
  </style>
</head>
<body>
  <div class="box">正常元素</div>
  <div class="box display-none">display: none 的元素</div>
  <div class="box">display: none 的上方元素会顶上来</div>

  <div class="box visibility-hidden">visibility: hidden 的元素</div>
  <div class="box">visibility: hidden 的下方元素不会移动</div>

  <!-- 子元素可见性示例 -->
  <div class="parent">
    父元素被隐藏
    <div class="child">但子元素仍然可见</div>
  </div>
</body>
</html>
```

## 2.3、CSS鼠标样式

| 属性 | 说明                                                     |
| -------- | ------------------------------------------------------------ |
| cursor   | 显示光标移动到指定的类型url    auto    crosshair    default    **pointer**    move    e-resize     ne-resize    nw-resize    n-resize    se-resize    sw-resize    s-resize    w-resize    text    wait    help |

**光标案例：**

```Html
css鼠标手型cursor中hand与pointer
Example：CSS鼠标手型效果 <a href="#" style="cursor:hand">CSS鼠标手型效果</a><br/>
Example：CSS鼠标手型效果 <a href="#" style="cursor:pointer">CSS鼠标手型效果</a><br/>
注：pointer也是小手鼠标，建议大家用pointer，因为它可以兼容多种浏览器。<br/>
Example：CSS鼠标由系统自动给出效果 <a href="#" style="cursor:auto">CSS鼠标由系统自动给出效果</a><br/>
Example：CSS鼠标十字型 效果 <a href="#" style="cursor:crosshair">CSS鼠标十字型 效果</a><br/>
Example：CSS鼠标I字型效果 <a href="#" style="cursor:text">CSS鼠标I字形效果</a><br/>
Example：CSS鼠标等待效果 <a href="#" style="cursor:wait">CSS鼠标等待效果</a><br/>
Example：CSS鼠标默认效果 <a href="#" style="cursor:default">CSS鼠标默认效果</a><br/>
Example：CSS鼠标向右的箭头效果 <a href="#" style="cursor:e-resize">CSS鼠标向右的箭头效果</a><br/>
Example：CSS鼠标向右上箭头效果 <a href="#" style="cursor:ne-resize">CSS鼠标向右上箭头效果</a><br/>
Example：CSS鼠标向上箭头效果 <a href="#" style="cursor:n-resize">CSS鼠标向上箭头效果</a><br/>
Example：CSS鼠标向左上箭头效果 <a href="#" style="cursor:nw-resize">CSS鼠标向左上箭头效果</a><br/>
Example：CSS鼠标向左箭头效果 <a href="#" style="cursor:w-resize">CSS鼠标向左箭头效果</a><br/>
Example：CSS鼠标向左下箭头效果 <a href="#" style="cursor:sw-resize">CSS鼠标向左下箭头效果</a><br/>
Example：CSS鼠标向下箭头效果 <a href="#" style="cursor:s-resize">CSS鼠标向下箭头效果</a><br/>
Example：CSS鼠标向右下箭头效果 <a href="#" style="cursor:se-resize">CSS鼠标向下箭头效果</a><br/>
```



# 第三节、CSS 定位(重点&难点)

## 3.1、CSS 定位属性

position 属性用于指定一个元素在文档中的定位方式。

position 属性的五个值：

> static    静态定位
>
> relative    相对定位
>
> fixed    固定定位
>
> absolute    绝对定位
>
> sticky    粘性定位
>

**元素可以使用的顶部，底部，左侧和右侧属性定位。**然而，这些属性无法工作，除非是先设定position属性(static除外)。他们也有不同的工作方式，这取决于定位方法。

| 属性 | 说明                                                     |
| -------- | ------------------------------------------------------------ |
| position | 指定元素的定位类型。<br>static HTML 元素的默认值，即没有定位，遵循正常的文档流对象。静态定位的元素不会受到 top, bottom, left, right影响。<br>absolute  绝对定位的元素的位置相对于最近的已定位父元素，如果元素没有已定位的父元素，那么它的位置相对于```<html>```。absolute 定位使元素的位置与文档流无关，因此不占据空间。absolute 定位的元素和其他元素重叠。fixed  元素的位置相对于浏览器窗口是固定位置。即使窗口是滚动的它也不会移动：Fixed定位使元素的位置与文档流无关，因此不占据空间。Fixed定位的元素和其他元素重叠。     <br>relative  相对定位元素的定位是相对其正常位置。移动相对定位元素，但它原本所占的空间不会改变。<br>sticky  sticky 英文字面意思是粘，粘贴，所以可以把它称之为粘性定位。**position: sticky;** 基于用户的滚动位置来定位。粘性定位的元素是依赖于用户的滚动，在 position:relative 与 position:fixed 定位之间切换。它的行为就像 position:relative; 而当页面滚动超出目标区域时，它的表现就像 position:fixed;，它会固定在目标位置。元素定位表现为在跨越特定阈值前为相对定位，之后为固定定位。这个特定阈值指的是 top, right, bottom 或 left 之一，换言之，指定 top, right, bottom 或 left 四个阈值其中之一，才可使粘性定位生效。否则其行为与相对定位相同。 |
| right    | 定义了定位元素右外边距边界与其包含块右边界之间的偏移。       |
| top      | 定义了一个定位元素的上外边距边界与其包含块上边界之间的偏移。 |
| bottom   | 定义了定位元素下外边距边界与其包含块下边界之间的偏移。       |
| left     | 定义了定位元素左外边距边界与其包含块左边界之间的偏移。       |

**案例：**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Position 实验</title>
    <style>
        /* 通用样式 */
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .box {
            width: 100px;
            height: 100px;
            margin: 10px;
            color: white;
        }

        /* static 定位 */
        .static {
            position: static;
            background-color: #3498db;
        }

        /* relative 定位 */
        .relative {
            position: relative;
            left: 50px;
            top: 20px;
            background-color: #2ecc71;
        }

        /* absolute 定位 */
        .parent {
            position: relative;
            width: 300px;
            height: 200px;
            border: 1px solid #ccc;
            margin: 20px;
        }

        .absolute {
            position: absolute;
            right: 20px;
            bottom: 20px;
            background-color: #e74c3c;
        }

        /* fixed 定位 */
        .fixed {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #f39c12;
        }

    </style>
</head>

<body>
    <!-- static 定位示例 -->
    <h2>static 定位</h2>
    <p>元素默认的定位方式，按照正常的文档流进行布局。</p>
    <div class="box static">Static</div>

    <!-- relative 定位示例 -->
    <h2>relative 定位</h2>
    <p>元素相对于其正常位置进行偏移，仍占据原文档流中的空间。</p>
    <div class="box relative">Relative</div>

    <!-- absolute 定位示例 -->
    <h2>absolute 定位</h2>
    <p>元素相对于最近的已定位祖先元素进行定位，如果没有已定位的祖先元素，则相对于文档的初始包含块。</p>
    <div class="parent">
        <div class="box absolute">Absolute</div>
    </div>

    <!-- fixed 定位示例 -->
    <h2>fixed 定位</h2>
    <p>元素相对于浏览器窗口进行定位，滚动页面时元素位置不变。</p>
    <div class="box fixed">Fixed</div>


    <!-- 用于产生滚动效果 -->
    <div style="height: 1000px;"></div>
</body>

</html>
```

**粘性定位实例:**

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>sticky 定位</title>
<style>
div.sticky {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    padding: 5px;
    background-color: #cae8ca;
    border: 2px solid #4CAF50;
}
</style>
</head>

<body>
    <p>尝试滚动页面。</p>
    <p>注意: IE/Edge 15 及更早 IE 版本不支持 sticky 属性。</p>

    <div class="sticky">我是粘性定位!</div>

    <div style="padding-bottom:2000px">
        <p>滚动我</p>
        <p>来回滚动我</p>
        <p>滚动我</p>
        <p>来回滚动我</p>
        <p>滚动我</p>
        <p>来回滚动我</p>
    </div>

</body>
</html>
```

**绝对定位和相对定位的区别：**

1、绝对定位不会占据原本的位置,相对定位会占据原来位置

2、绝对定位相对于父元素定位,相对定位是相对于原本的位置定位

## 3.2、CSS元素堆叠顺序

| **属性** | **说明**           |
| -------- | ------------------ |
| z-index  | 设置元素的堆叠顺序 |

![img](2_CSS进阶_image\wps1.jpg)

拥有更高堆叠顺序的元素总是会处于堆叠顺序较低的元素的前面。

注释：元素可拥有负的 z-index 属性值。

**z-index**  **仅能在定位元素上奏效(重点)**

案例代码：

```html
<!DOCTYPE html>
<html>
<head>
  <style>
    /* 基础容器样式 */
    .container {
      position: relative;
      width: 300px;
      height: 300px;
      margin: 50px auto;
      background: #eee;
    }

    /* 通用方块样式 */
    .box {
      position: absolute;
      width: 200px;
      height: 200px;
      padding: 20px;
      border: 2px solid black;
    }

    /* 堆叠顺序演示 */
    .red {
      background: rgba(255, 0, 0, 0.8);
      top: 30px;
      left: 30px;
      z-index: 1;
    }

    .blue {
      background: rgba(0, 0, 255, 0.8);
      top: 60px;
      left: 60px;
      /* 未设置 z-index (默认为 auto) */
    }

    .green {
      background: rgba(0, 255, 0, 0.8);
      top: 90px;
      left: 90px;
      z-index: 2;
    }

  </style>
</head>
<body>
  <!-- 基础堆叠顺序演示 -->
  <div class="container">
    <div class="box red">z-index: 1</div>
    <div class="box blue">默认堆叠顺序</div>
    <div class="box green">z-index: 2</div>
  </div>

  
</body>
</html>
```



## 3.3、CSS溢出处理

CSS overflow 属性用于控制内容溢出元素框时显示的方式。

| 属性   | 说明                                          |
| ---------- | ------------------------------------------------- |
| overflow   | 设置当元素的内容溢出其区域时发生的事情。          |
| overflow-y | 指定如何处理顶部/底部边缘的内容溢出元素的内容区域 |
| overflow-x | 指定如何处理右边/左边边缘的内容溢出元素的内容区域 |

如果元素中的内容超出了给定的宽度和高度属性，overflow 属性可以确定是否显示滚动条等行为。

这三个样式属性有四个共同的值:

​        visible​        默认值。内容不会被修剪，会呈现在元素框之外。

​        hidden​        内容会被修剪，并且其余内容是不可见的。

​        scroll​        内容会被修剪，但是浏览器会显示滚动条以便查看其余的内容。

​        auto​        如果内容被修剪，则浏览器会显示滚动条以便查看其余的内容。

**案例：**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSS 溢出处理案例</title>
    <style>
        /* 通用样式 */
        .box {
            width: 200px;
            height: 100px;
            border: 2px solid #333;
            margin: 20px;
            padding: 10px;
        }

        /* overflow: visible 示例 */
        .visible {
            overflow: visible;
            background-color: #e0f7fa;
        }

        /* overflow: hidden 示例 */
        .hidden {
            overflow: hidden;
            background-color: #f1f8e9;
        }

        /* overflow: scroll 示例 */
        .scroll {
            overflow: scroll;
            background-color: #fff3e0;
        }

        /* overflow: auto 示例 */
        .auto {
            overflow: auto;
            background-color: #fce4ec;
        }
    </style>
</head>

<body>
    <!-- overflow: visible 示例 -->
    <h2>overflow: visible</h2>
    <p>内容溢出时会显示在容器外部。</p>
    <div class="box visible">
        这是一段很长的文本内容，用于演示溢出效果。当内容超出容器的大小时，会显示在容器外部。这是一段很长的文本内容，用于演示溢出效果。
    </div>

    <!-- overflow: hidden 示例 -->
    <h2>overflow: hidden</h2>
    <p>内容溢出时会被隐藏，超出容器的部分将不可见。</p>
    <div class="box hidden">
        这是一段很长的文本内容，用于演示溢出效果。当内容超出容器的大小时，超出部分会被隐藏。这是一段很长的文本内容，用于演示溢出效果。
    </div>

    <!-- overflow: scroll 示例 -->
    <h2>overflow: scroll</h2>
    <p>无论内容是否溢出，都会显示滚动条，可通过滚动条查看溢出内容。</p>
    <div class="box scroll">
        这是一段很长的文本内容，用于演示溢出效果。当内容超出容器的大小时，可以通过滚动条查看。这是一段很长的文本内容，用于演示溢出效果。
    </div>

    <!-- overflow: auto 示例 -->
    <h2>overflow: auto</h2>
    <p>内容溢出时才会显示滚动条，不溢出则不显示。</p>
    <div class="box auto">
        这是一段很长的文本内容，用于演示溢出效果。当内容超出容器的大小时，会自动显示滚动条。这是一段很长的文本内容，用于演示溢出效果。
    </div>
</body>

</html>
```

# 第四节、CSS浮动(重点)

## 4.1、CSS元素浮动

CSS 的 float（浮动），会使元素向左或向右移动，其周围的元素也会重新排列。

| 属性  | 说明                                                         |
| ----- | ------------------------------------------------------------ |
| float | 指定一个盒子（元素）是否可以浮动。left：元素向左浮动。right：元素向右浮动。none：默认值。元素不浮动，并会显示在其在文本中出现的位置。 |

CSS 的 Float（浮动），会使元素向左或向右移动，其周围的元素也会重新排列。

元素的水平方向浮动，意味着元素只能左右移动而不能上下移动。

一个浮动元素会尽量向左或向右移动，直到它的外边缘碰到包含框或另一个浮动框的边框为止。

浮动层：给元素的float属性赋值后，就是脱离文档流，进行左右浮动，紧贴着父元素(默认为body文本区域)的左右边框。

而此浮动元素在文档流空出的位置，由后续的(非浮动)元素填充上去：块级元素直接填充上去，若跟浮动元素的范围发生重叠，浮动元素覆盖块级元素。内联元素：有空隙就插入。

## 4.2、CSS清除浮动

| 属性 | 说明                                                     |
| -------- | ------------------------------------------------------------ |
| clear    | 指定不允许元素周围有浮动元素。left：在左侧不允许浮动元素。right：在右侧不允许浮动元素。both： 在左右两侧均不允许浮动元素。None  默认值。允许浮动元素出现在两侧。 |

“float是魔鬼，会影响其他相邻元素；但是clear是小白，其只会影响自身，不会对其他相邻元素造成影响！”

元素盒子的边不能和前面的浮动元素相邻，那么就是自己下移。

## 4.3、CSS清除浮动影响的方式

**案例:**

![img](2_CSS进阶_image\wps2.jpg)

使用了float之后，父级盒子的高度变为0了。

![img](2_CSS进阶_image\wps3.jpg)

### 4.3.1、给父级元素单独定义高度（height）

![img](2_CSS进阶_image\wps4.jpg)

原理：如果父级元素没有定义高度，父元素的高度完全由子元素撑开时，父级div手动定义height，就解决了父级div无法自动获取到高度的问题。

优点：简单、代码少、容易掌握。

缺点：只适合高度固定的布局，要给出精确的高度，如果高度和父级div不一样时，会产生问题。对于响应式布局会有很大影响。

### 4.3.2、在标签结尾处(前)加空div标签 clear:both

![img](2_CSS进阶_image\wps5.jpg)

原理：添加一个空div，利用css提供的clear:both清除浮动，让父级div能自动获取到高度。

优点：简单、代码少、浏览器支持好、不容易出现怪问题

缺点：不少初学者不理解原理；如果页面浮动布局多，就要增加很多空div，不利于页面的优化。

### 4.3.3、父级div定义 伪元素:after 和 zoom

![img](2_CSS进阶_image\wps6.jpg)

原理：元素生成伪类的作用和效果相当于方法2中的原理，但是IE8以上和非IE浏览器才支持:after，zoom(IE专有属性)可解决ie6,ie7浮动问题。

优点：浏览器支持好、不容易出现怪问题，写法是固定的，不理解也可以直接复制使用；（推荐使用此种方法，简单便捷，只需添加一个class即可解决问题）

缺点：css代码多、不少初学者不理解原理，要两句代码结合使用才能让主流浏览器都支持。

### 4.3.4、父级div定义 overflow:hidden

![img](2_CSS进阶_image/wps7.jpg)

优点：简单、代码少、浏览器支持好

缺点：不能和position配合使用，因为超出的尺寸的会被隐藏。

**案例**

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Float 属性基本案例</title>
    <style>

      .box{
        border:1px solid red;
      }
        /* 定义浮动列的样式 */
       .column {
            width: 200px;
            height: 200px;
            margin: 10px;
            background-color: #3498db;
            color: white;
            text-align: center;
            float: left;
        }

        /* 清除浮动的样式 */
       .clearfix::after {
            content: "";
            display: block;
            clear: both;
        }
    </style>
</head>

<body>
    <div class="box clearfix">
        <div class="column">列 1</div>
        <div class="column">列 2</div>
        <div class="column">列 3</div>
    </div>
</body>

</html>
```



# 第五节、CSS对齐方式

## 5.1、元素居中对齐

要水平居中对齐一个元素(如 ```<div>```), 可以使用 margin: auto;或margin:0 auto。

设置到元素的宽度将防止它溢出到容器的边缘。

元素通过指定宽度，并将两边的空外边距平均分配：

```css
.center {
    margin: auto;
    width: 50%;
    border: 3px solid green;
    padding: 10px;
}
```

## 5.2、文本居中对齐

如果仅仅是为了文本在元素内居中对齐，可以使用 text-align: center;

```css
.center {
    text-align: center;
    border: 3px solid green;
}
```

## 5.3、左右对齐 - 使用定位方式

我们可以使用 position: absolute; 属性来对齐元素:

```css
.right {
    position: absolute;
    right: 0px;
    width: 300px;
    border: 3px solid #73AD21;
    padding: 10px;
}
```

注释：绝对定位元素会被从正常流中删除，并且能够交叠元素。

## 5.4、左右对齐 - 使用 float 方式

我们也可以使用 float 属性来对齐元素:

```css
.right {
    float: right;
    width: 300px;
    border: 3px solid #73AD21;
    padding: 10px;
}
```

当像这样对齐元素时，对 ```<body>``` 元素的外边距和内边距进行预定义是一个好主意。这样可以避免在不同的浏览器中出现可见的差异。

## 5.5、文本垂直居中对齐 - 使用 padding

CSS 中有很多方式可以实现垂直居中对齐。 一个简单的方式就是头部底部使用 padding:

```css
.center {
    padding: 70px 0;
    border: 3px solid green;
}
```

如果要水平和垂直都居中，可以使用 padding 和 text-align: center:

## 5.6、文本垂直居中 - 使用 line-height

line-height和height保持一致即可；

```css
.center {
    line-height: 200px;
    height: 200px;
    border: 3px solid green;
    text-align: center;
}
/* 如果文本有多行，添加以下代码: */
.center p {
    line-height: 1.5;
    display: inline-block;
    vertical-align: middle;
}
```

# 第六节、CSS精灵截图技术(CSS 图像拼合技术)

## 6.1、什么是css sprites

css sprites直译过来就是CSS精灵。通常被解释为“CSS图像拼合”或“CSS贴图定位”。**其实就是通过将多个图片融合到一张图里面，然后通过CSS background背景定位技术技巧布局网页背景**。这样做的好处也是显而易见的，**因为图片多的话，会增加http的请求，会促使了网站性能的减低，特别是图片特别多的网站，如果能用css sprites降低图片数量，带来的将是速度的提升**。

css sprites是什么通俗解释：CSS Sprites其实就是把网页中一些背景图片整合拼合成一张图片中，再利用DIV CSS的“background-image”，“background- repeat”，“background-position”的组合进行背景定位，background-position可以用数字能精确的定位出背景图片在布局盒子对象位置。

## 6.2、适用场合

**1、适合：一般小图标素材:**

小的图标ico类素材，一般图标很小十多像素几十像素的宽度高度，这种适合拼合成一张图实现sprites background背景定位布局。多小ico太多自然加载网页时瞬间会消耗些http iis链接数，但很快加载完又会释放。

ICO是Windows的图标文件格式，图标文件可以存储单个图案、多尺寸、多色板的图标文件。一个图标实际上是多张不同格式的图片的集合体，并且还包含了一定的透明区域。

**2、不适合：大图大背景:**

大背景一般用于网页背景，拼合时，设置为网页背景时所有背景都会显示出来。大图拼接拼合会增大图片大小，网络带宽不好的访问者访问时由于背景图大文件大会加载稍慢些，所以大图不推荐拼接拼合来使用css sprites背景定位布局。

**3、sprites适合推荐小结:**

一般此sprites拼合布局用于局部小盒子布局不适合大背景大布局背景使用。比如小局部布局小图标背景、小导航背景等DIVCSS布局。

## 6.3、css sprites优势与缺点劣势

1、sprites优势：

若干小图标拼合成一张图后布局，减少http请求数，对于大战大流量网站来说隐形优势很显然的，从而隐形地提升了网站性能。对于大流量网站来说本来http请求数比较宝贵，使用DIV+CSS Sprites这样可以大大的提高了页面的性能，这是CSS Sprites最大的优点，也是其被广泛传播和应用的主要原因，同时也减少图片文件数目。

2、sprites缺点

在图片合并的时候，你要把多张图片有序的合理的合并成一张图片，还要留好只够的空间，防止板块内不会出现不必要的背景，如果留空间或拼合位置不合适，在布局时容易出现布局这个盒子对象时，设置背景出现拼合相邻图片，干扰图片的情况;

![img](2_CSS进阶_image\wps8.jpg)

CSS Sprites在开发的时候比较麻烦，你要通过photoshop(PS)或其他工具测量计算每一个背景单元的精确位置，这是针线活，没什么难度，但是很繁琐;

CSS Sprites在维护的时候比较麻烦，sprites是一般双刃剑，如果页面背景有少许改动，一般就要改这张合并的图片，无需改的地方最好不要动，这样避免改动更多的css，如果在原来的地方放不下，有只能（最好）往下加图片，这样图片的字节就增加了，因为每次的图片改动都得往这个图片删除或添加内容，显得稍微繁琐，而且重新算图片的位置（尤其是这种上千px的图）也是一件颇为不爽的事情。

由于图片的位置需要固定为某个绝对数值，这就失去了诸如center之类的灵活性。

3、推荐小结

由于拼接图片需要一定经验技巧（做实践即可快速掌握）、测量定位数值、修改不是那么灵活等原因，一般小网站站、小流量网站、一般企业网站不是很推荐使用CSS Sprites，因为使用CSS Sprites会比普通单个背景图片布局要耗费时间和精力，所以不是很推荐小站。

但这个布局技巧也必须要学会掌握灵活布局才是目的。小站HTTP请求数丰富这点拼接其实也起不来什么优势反而会浪费宝贵时间。相反大网站大流量网站推荐使用，这样比较值得。

## 6.4、实例教程

### 6.4.1、素材与要实现效果截图(拼合ico图标素材实现列表不同图标效果截图)

![img](2_CSS进阶_image\wps9.jpg)

### 6.4.2、sprites实例教程解释介绍

首先这些图标素材是放在同一张图片上（PS拼合），然后实现成列表类布局，列表每个前图标不同。使用div css sprites实现此布局（其实使用background样式实现）。

首先此列表布局我们使用ul li列表布局，每个li站一行排版，对ul设置padding实现四周内容与边框一定间距效果，因为每个li前面图标不同，但此背景图片是拼合在一张图片上，所以这里做li里开始使用span标签实现这个不同图标效果，每个图标不同为了区别span所以对span设置不同class，不同class对应设置定位相应的图标。

### 6.4.3、实例教程

**sprites案例图片素材:**

![img](2_CSS进阶_image\wps10.jpg)

图片宽60，高40 可以分为上下两排，每排三个长20宽20共6个正方形小图标。这样使用sprites技术，用一张图实现了六个图标的显示，由于只用了一张图所以只向服务器发送了一次请求，节约了时间。

**实例代码：**

```html
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1, maximum-scale=1,minimal-ui, user-scalable=no"/>
    <style>
        .sprites div {
            margin: 5px;
        }
        .sprites span {
            float: left;
            width: 20px;
            height: 20px;
            background-image: url(sprite.png);
            background-size: 60px 40px;
        }
        .sprites1{
            background-position: 0 0;
        }
        .sprites2{
            background-position: -20px 0;
        }
        .sprites3{
            background-position: 0 -20px;
        }
        .sprites4{
            background-position: -20px -20px;
        }
        .sprites5{
            background-position: -40px 0;
        }
        .sprites6{
            background-position: -40px -20px;
        }
    </style>
</head>
<body>
<div class="sprites">
    <div><span class="sprites1"></span>付款图标</div>
    <div><span class="sprites2"></span>删除图标</div>
    <div><span class="sprites3"></span>存款图标</div>
    <div><span class="sprites4"></span>粘贴图标</div>
    <div><span class="sprites5"></span>笑脸图标</div>
    <div><span class="sprites6"></span>编辑图标</div>
</div>
</body>
</html>
```

**sprites实例效果：**

![img](2_CSS进阶_image\wps11.jpg)

说明：背景background-position有两个数值，前一个代表靠左距离值（可为正可为负），第二个数值代表靠上距离值（可为正可为负）。当为正数时，代表背景图片作为对象盒子背景图片时靠左和靠上多少距离多少开始显示背景图片；当为负数时代表背景图片作为盒子对象背景图片，将背景图片拖动超出盒子对象左边多远，拖动超出盒子对象上边多远开始显示此背景图片。

## 学习总结 

​        通过对本章课程的学习，我们掌握了CSS的各种高级选择器的使用方法，CSS元素的显示类型及可见性，CSS元素的定位属性、浮动、对齐方式和CSS精灵截图技术。

## 任务单

### 理论性任务单

1.写出6个CSS高级选择器及其作用。

2.写出Display属性的值及其含义。

3.元素的堆叠顺序是由哪个属性决定的？

4.简述什么是CSS的浮动，它是由哪个属性如何配置的？

5.CSS如何配置文本垂直居中？

6.什么是CSS  Sprites技术，它适用于什么场合，有什么优劣。

### 实操型任务单

1. 使用样式完成以下操作

（1）包含1个网页。 
（2）完成一个60\*20px的区域，作为按钮 
         a) 按钮四角为圆角 
         b) 用阴影做出按钮立体效果 
         c）光标形状改为手形 

![](2_CSS进阶_image/20200518231540933.gif)

2. 实现一个后台管理页面：技术点如下。
   1. html：ul、li、a、div、h、p
   2.  宽高、浮动、内边距、外边距、背景色、字体颜色、阴影

![image-20250304192453944](images/image-20250304192453944.png)